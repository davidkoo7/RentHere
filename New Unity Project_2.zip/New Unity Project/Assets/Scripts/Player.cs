﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour {

    private float maxSpeed = 2.5f;
    private float jumpPower = 275f;
    private float speed = 35f;

    private BoxCollider2D boxCollider;
    private Rigidbody2D rb2d;
    private Animator animate;

    public bool grounded = true;

    // Use this for initialization
    void Start () {
        boxCollider = GetComponent<BoxCollider2D>();
        rb2d = GetComponent<Rigidbody2D>();
        animate = GetComponent<Animator>();
	}
	
	// Update is called once per frame
	void Update () {
        float h = Input.GetAxis("Horizontal");

        if (h == 0 || !grounded)
            animate.speed = 0;
        else
            animate.speed = 1.3f;

        if (Input.GetAxis("Horizontal") < 0)
            transform.localScale = new Vector3(0.75f, transform.localScale.y, transform.localScale.z);
        else if (Input.GetAxis("Horizontal") > 0)
            transform.localScale = new Vector3(-0.75f, transform.localScale.y, transform.localScale.z);

        if (Input.GetButtonDown("Jump") && grounded)
        {
            rb2d.AddForce(Vector2.up * jumpPower);
        }

    }

    void FixedUpdate()
    {
        Vector3 easeVelocity = rb2d.velocity;
        easeVelocity.x *= 0.75f;
        easeVelocity.y = rb2d.velocity.y;
        easeVelocity.z = 0;

        if(grounded)
        {
            rb2d.velocity = easeVelocity;
        }

        rb2d.AddForce(Vector2.right * speed * Input.GetAxis("Horizontal"));

        rb2d.velocity = new Vector2(Mathf.Clamp(rb2d.velocity.x, -maxSpeed, maxSpeed), rb2d.velocity.y);

       
    }
}
